#include "lib/stpcpy.c"
