#include "lib/strcspn.c"
