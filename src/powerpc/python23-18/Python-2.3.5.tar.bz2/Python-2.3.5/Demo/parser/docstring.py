"""Some documentation.
"""
