--TEST--
DomDocument::schemaValidateSource() - string that is not a schema
--CREDITS--
Daniel Convissor <danielc@php.net>
# TestFest 2009 NYPHP
--SKIPIF--
<?php require_once('skipif.inc'); ?>
--FILE--
<?php

$doc = new DOMDocument;

$doc->load(dirname(__FILE__)."/book.xml");

$result = $doc->schemaValidateSource('string that is not a schema');
var_dump($result);

?>
--EXPECTF--
Warning: DOMDocument::schemaValidateSource(): Entity: line 1: parser error : Start tag expected, '<' not found in %s.php on line %d

Warning: DOMDocument::schemaValidateSource(): string that is not a schema in %s.php on line %d

Warning: DOMDocument::schemaValidateSource(): ^ in %s.php on line %d

Warning: DOMDocument::schemaValidateSource(): Failed to parse the XML resource 'in_memory_buffer'. in %s.php on line %d

Warning: DOMDocument::schemaValidateSource(): Invalid Schema in %s.php on line %d
bool(false)
